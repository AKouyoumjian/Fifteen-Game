package cs3500.set.view;

import cs3500.set.model.hw02.SetGameModelState;
import cs3500.set.model.hw02.SetThreeGameModel;

/**
 * Class for SetGameTextView.
 */
public class SetGameTextView implements SetGameView {
  private SetGameModelState state;

  /**
   * Constructor for SetGameModelState class.
   *
   * @param state the inputted state to be viewed.
   */
  public SetGameTextView(SetGameModelState state) {
    this.state = state;
    if (this.state == null) {
      throw new IllegalArgumentException("the model you give cannot be null");
    }

  }

  /**
   * Produces a textual view of the grid of cards of the current game.
   * Each card is displayed as initials of all of its attributes.
   * For instance, if a card has a single red oval, the card is displayed as 1RO.
   * If a card has three squiggly purple shapes, the card is displayed as 3PS.
   *
   * @return representation of the current state of the game
   */
  public String toString() throws IllegalArgumentException {
    if (this.state instanceof SetThreeGameModel) {
      SetThreeGameModel s = (SetThreeGameModel) this.state;

      return s.toString();
    }

    throw new IllegalArgumentException(
            "state field of SetGameTextView must be a SetGameThreeModel");
  }


}
