package cs3500.set.view;

import org.junit.Test;
import cs3500.set.model.hw02.SetThreeGameModel;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

/**
 * Class for testing SetGameTextViewTest class.
 */
public class SetGameTextViewTest {

  /**
   * Test for toString.
   */
  @Test
  public void testToString() {
    SetThreeGameModel game = new SetThreeGameModel();
    game.startGameWithDeck(game.getCompleteDeck(), 3, 3);
    SetGameTextView view = new SetGameTextView(game);

    assertEquals("1EO 1EQ 1ED" + "\n" + "1SO 1SQ 1SD" + "\n" + "1FO 1FQ 1FD",
            view.toString());

  }

  /**
   * Test for invalid constructor.
   */
  @Test
  public void testInvalidConstructor() {
    try {
      SetGameTextView view = new SetGameTextView(null);
      fail("should have thrown IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      // do nothing
    }
  }
}